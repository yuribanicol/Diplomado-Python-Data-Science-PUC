# Importar liibrerías necesarias. NO SE DEBE IMPORTAR NINGUNA OTRA LIBRERÍA.
import mysql.connector as db
import csv

# Desde este punto en adelante se debe crear el código solicitado.
